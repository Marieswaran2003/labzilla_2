#!/bin/bash

# Define constants
USER_NAME="training18"
USER_HOME="/home/$USER_NAME"
MARKS_PER_QUESTION=50
MAX_MARKS=300
PASSING_MARKS=210
TOTAL_MARKS=0

# Function to check if a container is running
validate_container() {
    local container_name=$1
    local expected_message=$2
    local port=$3

    echo "Validating container $container_name on port $port..."

    if ssh training18@workstation podman ps --filter "name=$container_name" | grep -q "$container_name"; then
        echo "  Container $container_name is running."
    else
        echo "  ERROR: Container $container_name is not running."
        return 1
    fi

    response=$(curl -s http://localhost:$port)

    if [[ $response == "$expected_message" ]]; then
        echo "  Response validated successfully: $response"
        return 0
    else
        echo "  ERROR: Response mismatch. Got: $response, Expected: $expected_message"
        return 1
    fi
}

# ==========================
# Validation Start
echo "Starting validation..."
# ==========================

# **Q1: Simple Container Validation**
validate_container "acme-demo-html" "<html><body><h1>Welcome to Nginx</h1></body></html>" 8001
[[ $? -eq 0 ]] && TOTAL_MARKS=$((TOTAL_MARKS + MARKS_PER_QUESTION))

# **Q2: Nginx Application Validation**
validate_container "acme-demo-nginx" "<html><body><h1>Im running successfully man all the best for your exams" 8002
[[ $? -eq 0 ]] && TOTAL_MARKS=$((TOTAL_MARKS + MARKS_PER_QUESTION))

# **Q3: Multi-container Port Sharing Validation**
validate_container "acme_nginx_container_1" "Acme_Container_1" 8003
STATUS_1=$?
validate_container "acme_nginx_container_2" "Acme_Container_2" 8003
STATUS_2=$?

if [[ $STATUS_1 -eq 0 || $STATUS_2 -eq 0 ]]; then
    TOTAL_MARKS=$((TOTAL_MARKS + MARKS_PER_QUESTION))
fi

# **Q4: Custom Container Image Validation**
sql_file="/home/training18/projects/mariadb/exports/app.sql"
if [ -f "$sql_file" ]; then
    echo "  SQL file found: $sql_file"
    TOTAL_MARKS=$((TOTAL_MARKS + MARKS_PER_QUESTION))
else
    echo "  ERROR: SQL file not found in $sql_file"
fi

# **Q5: Multi-container Deployment with Network and Volume Validation**
network_name="acme-wp"
volumes=("acme-wp-backend" "acme-wp-app" "acme-wordpress-data")
containers=("mariadb" "acme-wp-app" "acme-wordpress")

network_exists=true
ssh training18@workstation podman network ls | grep -q "$network_name" || network_exists=false
[[ "$network_exists" == false ]] && echo "  ERROR: Network '$network_name' not found."

for volume in "${volumes[@]}"; do
    ssh training18@workstation podman volume ls | grep -q "$volume" || echo "  ERROR: Volume '$volume' not found."
done

containers_running=true
for container in "${containers[@]}"; do
    ssh training18@workstation podman ps --filter "name=$container" | grep -q "$container" || containers_running=false
done

[[ $containers_running == true ]] && TOTAL_MARKS=$((TOTAL_MARKS + MARKS_PER_QUESTION))

# **Q6: Troubleshooting Multi-container Stack**
# Check logs, status, and connectivity
echo "Validating troubleshooting of containers..."
troubleshooting_success=true

for container in "${containers[@]}"; do
    if ssh training18@workstation podman logs "$container" | grep -q "ERROR"; then
        echo "  ERROR: Issues detected in logs of $container."
        troubleshooting_success=false
    else
        echo "  No errors found in logs of $container."
    fi
done

if [[ "$troubleshooting_success" == true ]]; then
    TOTAL_MARKS=$((TOTAL_MARKS + MARKS_PER_QUESTION))
fi

# ==========================
# Final Summary
echo "Validation completed."
echo "----------------------------------------"
echo "Total Marks Scored: $TOTAL_MARKS / $MAX_MARKS"

if [[ $TOTAL_MARKS -ge $PASSING_MARKS ]]; then
    echo "RESULT: PASSED"
else
    echo "RESULT: FAILED"
fi

exit 0
