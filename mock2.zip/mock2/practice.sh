#!/bin/bash

# Ensure the 'student' user exists
if ! id "student" &>/dev/null; then
    echo "Creating user 'student'..."
    useradd -m student
    echo "User 'student' created successfully."
else
    echo "User 'student' already exists."
fi



# Ensure the necessary directories exist and permissions are correct

echo "Creating directory structure..."
sudo mkdir -p /home/student/marvels/nginx/html/
sudo mkdir -p /home/student/marvels/mariadb/
sudo mkdir -p /home/student/marvels/mariadb/exports
sudo mkdir -p /home/student/marvels/mariadb/scripts

sudo chown -R student:student /home/student/marvels/nginx/html/
sudo chown -R student:student /home/student/marvels/mariadb/
sudo chown -R student:student /home/student/marvels/mariadb/exports
sudo chown -R student:student /home/student/marvels/mariadb/scripts

# Export script for MariaDB
sudo cat > /home/student/marvels/mariadb/scripts/export.sh <<EOF
mysql -u root -pacme mysql > /home/marvelsMysql.sql
EOF

sudo chown student:student /home/student/marvels/mariadb/scripts/export.sh
sudo chmod +x /home/student/marvels/mariadb/scripts/export.sh
sudo chmod 755 /home/student/marvels/mariadb/scripts/export.sh
sudo chmod 755 /home/student/marvels/mariadb/scripts/

# Container files for MariaDB
sudo cat > /home/student/marvels/mariadb/marvels_containerfile <<EOF
# Base image

# Arguments

# Environment variables

EOF

sudo chown student:student /home/student/marvels/mariadb/marvels_containerfile

sudo cat > /home/student/marvels/mariadb/marvels_export_containerfile <<EOF
# Container for export operations

# Commands to export database

EOF

sudo chown student:student /home/student/marvels/mariadb/marvels_export_containerfile

# HTML Content for Nginx
sudo echo "Creating index.html file..."
sudo echo "<html><body><h1>Welcome to Marvels Project: Service is active.</h1></body></html>" > /home/student/marvels/nginx/html/index.html
sudo chown student:student /home/student/marvels/nginx/html/index.html
sudo echo "File created: /home/student/marvels/nginx/html/index.html"

# Install necessary packages
sudo dnf install container-tools -y
sudo dnf install nginx -y
sudo dnf install httpd -y

# Nginx Web Directory Setup
sudo mkdir -p /home/student/marvels/nginx_web
sudo mkdir -p /home/student/marvels/nginx_web/html
sudo mkdir -p /home/student/marvels/nginx_web/conf

sudo chown -R student:student /home/student/marvels/nginx_web
sudo chown -R student:student /home/student/marvels/nginx_web/html/
sudo chown -R student:student /home/student/marvels/nginx_web/conf/

# HTML File for Web Service
sudo echo "<html><body><h1>We’re in the endgame now.</h1></body></html>" > /home/student/marvels/nginx_web/html/index.html

# Create default.conf for Nginx
sudo echo "Creating default.conf for Nginx"
sudo cat > /home/student/marvels/nginx_web/conf/default.conf <<EOF
# For more information on configuration, see:
#   * Official English Documentation: http://nginx.org/en/docs/
#   * Official Russian Documentation: http://nginx.org/ru/docs/


worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;

# Load dynamic modules. See /usr/share/doc/nginx/README.dynamic.
include /usr/share/nginx/modules/*.conf;

events {
    worker_connections 1024;
}

http {
    log_format  main  '$remote_addr - $remote_user [$time_local] "$request" '
                      '$status $body_bytes_sent "$http_referer" '
                      '"$http_user_agent" "$http_x_forwarded_for"';

    

    sendfile            on;
    tcp_nopush          on;
    tcp_nodelay         on;
    keepalive_timeout   65;
    types_hash_max_size 2048;

    include             /etc/nginx/mime.types;
    default_type        application/octet-stream;

    # Load modular configuration files from the /etc/nginx/conf.d directory.
    # See http://nginx.org/en/docs/ngx_core_module.html#include
    # for more information.
    include /etc/nginx/conf.d/*.conf;

    server {
        listen       8080 default_server;
        server_name  _;
        root         /usr/share/nginx/html/;

        # Load configuration files for the default server block.
        include /etc/nginx/default.d/*.conf;

        location / {
        }

        error_page 404 /404.html;
            location = /40x.html {
        }

        error_page 500 502 503 504 /50x.html;
            location = /50x.html {
        }
    }
}
EOF


echo "Logging into Docker registry as student..."
sudo -u student bash -c 'echo "redhat321" | podman login docker.io -u admin034 --password-stdin'

sudo -u student bash -c 'echo "developer" | podman login registry.ocp4.example.com:8443 -u developer --password-stdin'


echo "Logging into Docker registry as student..."     
# Step 6: Install httpd, enable and start the service
echo "Installing httpd server..."
sudo dnf install httpd -y

echo "Enabling and starting httpd service..."
sudo systemctl enable httpd
sudo systemctl start httpd

sudo cp ~/labzilla_2/mock2/* /var/www/html/


echo "All tasks completed successfully. Good luck!"
echo "Your Eligible for practice now..!!"